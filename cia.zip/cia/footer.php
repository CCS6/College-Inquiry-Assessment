<footer id="footer">
<div class="container">
<div class="row text-center">
  <p class="separate-p">&copy; CIA. All Rights Reserved.</p>
  <div class="credits">
    <!--
        All the links in the footer should remain intact.
        You can delete the links only if you purchased the pro version.
        Licensing information: https://bootstrapmade.com/license/
        Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Baker
    -->
</div>
</div>
</div>
</footer>
<!---->
</div>
    <script src="js/jquery.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/wow.js"></script>
    <script src="js/jquery.bxslider.min.js"></script>
    <script src="js/custom.js"></script>
    <script src="js/index.js"></script>
    <script src="js/tooltips.js"></script>
</body>
</html>
