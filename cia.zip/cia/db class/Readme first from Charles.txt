First, make a new database(any name for testing)
Next, create 4 attributes(id(PRIMARY, A_I ON), username, password, email)
Next, insert some data for testing(you can not have data in id since it is A_I(AUTO_INCREMENT) on.)
Last, enjoy the database class...

Source: https://www.youtube.com/watch?v=NLTO82RXlpQ