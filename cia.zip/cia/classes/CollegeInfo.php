<?php
    class Question{
        public function __construct(){

        }

        public function add(){

        }

        public function edit(){

        }

        public function delete(){

        }

        public function view(){

        }
    }
?>
