<footer class="footer text-right">
    2015 © Moltran.
</footer>

</div>
<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->

<!-- MODAL -->
<div id="dialog" class="modal-block mfp-hide">
<section class="panel panel-info panel-color">
    <header class="panel-heading">
        <h2 class="panel-title">Are you sure?</h2>
    </header>
    <div class="panel-body">
        <div class="modal-wrapper">
            <div class="modal-text">
                <p>Are you sure that you want to delete this row?</p>
            </div>
        </div>

        <div class="row m-t-20">
            <div class="col-md-12 text-right">
                <button id="dialogConfirm" class="btn btn-primary">Confirm</button>
                <button id="dialogCancel" class="btn btn-default">Cancel</button>
            </div>
        </div>
    </div>

</section>
</div>



</div>
<!-- END wrapper -->

    <script>
        var resizefunc = [];
    </script>

    <!-- jQuery  -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/waves.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="js/jquery.scrollTo.min.js"></script>
    <script src="assets/jquery-detectmobile/detect.js"></script>
    <script src="assets/fastclick/fastclick.js"></script>
    <script src="assets/jquery-slimscroll/jquery.slimscroll.js"></script>
    <script src="assets/jquery-blockui/jquery.blockUI.js"></script>


    <!-- CUSTOM JS -->
    <script src="js/jquery.app.js"></script>

    <!-- Examples -->
    <script src="assets/magnific-popup/magnific-popup.js"></script>
    <script src="assets/jquery-datatables-editable/jquery.dataTables.js"></script>
    <script src="assets/datatables/dataTables.bootstrap.js"></script>
    <script src="assets/jquery-datatables-editable/datatables.editable.init.js"></script>

</body>
</html>
