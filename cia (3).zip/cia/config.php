<?php
    require_once 'classes/Database.php';
    $GLOBALS['db'] = new Database('localhost','root','','cia');
 ?>
